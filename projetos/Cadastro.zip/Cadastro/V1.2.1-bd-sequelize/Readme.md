1- Para executar esse projeto, certifique que o usuario root tenha todas as permissões do Bd
2- No Sql, crie um banco de dados chamado cadVendas
3- vá na pasta models/vendas e descomente o código vendas.sync({force: true});, e execute no terminal, para que o node crie essa tabela no BD, depois comente-a de novo
4- Execute o app.js
5- para acessa a página use o url "localhost:8081/cadastro-vendas"
