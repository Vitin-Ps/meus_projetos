export const Produto = {
  nome: '',
  valor: 0,
};
